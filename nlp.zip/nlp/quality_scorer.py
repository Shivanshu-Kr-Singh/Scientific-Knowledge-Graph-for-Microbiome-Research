def score(paper):
    s = 0
    if (paper.journal_info.get("quartile")== "Q1"):
        s += 0.3
    if (paper.article_type_normalized== "rct"):
        s += 0.3
    if (paper.data_availability):
        s += 0.2
    return min(s,1)