import requests
from bs4 import BeautifulSoup


class EuropePMCFullText:

    BASE = (
        "https://www.ebi.ac.uk/"
        "europepmc/webservices/rest/"
    )

    def fetch(
        self,
        pmcid
    ):

        url = (
            f"{self.BASE}"
            f"{pmcid}/fullTextXML"
        )

        r = requests.get(
            url,
            timeout=30
        )

        if r.status_code != 200:

            return None

        soup = BeautifulSoup(
            r.text,
            "xml"
        )

        return {

            "abstract":
            soup.find_text(
                "abstract"
            ),

            "methods":
            soup.find_text(
                "methods"
            ),

            "results":
            soup.find_text(
                "results"
            ),

            "discussion":
            soup.find_text(
                "discussion"
            ),

            "fetch_source":
            "xml",

            "fetch_status":
            "success"
        }