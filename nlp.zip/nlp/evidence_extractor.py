import re

def extract(text):

    out = {}

    n = re.search(r"(\d+)\s+patients",text,re.I)

    if n:
        out["sample_size"] = int(n.group(1))
    methods = []

    for m in ["16s","shotgun","metatranscriptomics"]:

        if m in text.lower():
            methods.append(m)
    out["methods"] = methods
    return out