"""
nlp/pipeline.py
----------------
Orchestrates all 5 NLP modules into one processing pass per paper.

HOW IT WORKS:
  For each PaperRecord from Layer 1:
    1. ArticleClassifier  → normalized article type + confidence
    2. JournalClassifier  → impact factor, quartile, field
    3. SectionParser      → abstract split into sections (+ full text if OA)
    4. NERExtractor       → taxa, diseases, methods, body sites, treatments
    5. DataAvailability   → accession numbers, repos, status

  All outputs merge into one EnrichedPaperRecord.
  Saves results to data/processed/enriched_YYYYMMDD_HHMMSS.json
  Passes the enriched list to Layer 3.

PERFORMANCE NOTES:
  - Rule-based modules (classifier, section parser, data_availability):
    ~1ms per paper — can process 1000 papers in ~1 second
  - NER rule-based:
    ~5ms per paper
  - NER with BioBERT model:
    ~500ms per paper on CPU — set use_ner_model=False for faster runs
    ~50ms per paper on GPU
"""

import json
from datetime import datetime
from pathlib import Path
from typing import List, Optional
from loguru import logger
from tqdm import tqdm

from config import PROC_DIR
from models import PaperRecord
from nlp.enriched_record import EnrichedPaperRecord, DataAvailabilityInfo, JournalInfo
from nlp.article_classifier import ArticleClassifier
from nlp.journal_classifier import JournalClassifier
from nlp.ner import NERExtractor
from nlp.section_parser import SectionParser
from nlp.data_availability import DataAvailabilityExtractor
from nlp.fulltext.fulltext_orchestrator import (FullTextOrchestrator)

from nlp.study_design import (extract_design)
from nlp.evidence_extractor import (extract as extract_evidence)
from nlp.quality_scorer import (score as quality_score)

class NLPPipeline:
    """
    Processes a list of PaperRecords through all 5 NLP modules.
    Produces a list of EnrichedPaperRecords ready for Layer 3.
    """

    def __init__(self, use_ner_model: bool = False):
        """
        use_ner_model: Whether to load BioBERT for NER.
                       False = rules only (fast, no GPU needed)
                       True  = rules + BioBERT (better recall, needs ~4GB RAM or GPU)
        """
        logger.info("Initializing NLP pipeline modules...")
        self.article_classifier  = ArticleClassifier()
        self.journal_classifier  = JournalClassifier()
        self.ner_extractor       = NERExtractor(use_model=use_ner_model)
        self.section_parser      = SectionParser()
        self.data_av_extractor   = DataAvailabilityExtractor()
        self.fulltext = (FullTextOrchestrator())
        logger.success("NLP pipeline ready")

    def process_all(
        self,
        papers: List[PaperRecord],
        use_ner_model: bool = False,
    ) -> List[EnrichedPaperRecord]:
        """
        Processes all papers and returns enriched records.
        Saves to disk automatically.
        """
        logger.info(f"Starting NLP processing for {len(papers)} papers")
        enriched = []
        errors = 0

        for paper in tqdm(papers, desc="NLP processing"):
            try:
                result = self.process_one(paper)
                enriched.append(result)
            except Exception as e:
                logger.error(f"[pipeline] Failed on paper '{paper.title[:60]}': {e}")
                errors += 1
                continue

        logger.success(f"NLP complete: {len(enriched)} enriched, {errors} errors")
        output_path = self._save(enriched)
        logger.success(f"Saved → {output_path}")
        self._print_summary(enriched)
        return enriched

    def process_one(self, paper: PaperRecord) -> EnrichedPaperRecord:
        """
        Runs all 5 NLP modules on one paper.

        WHAT HAPPENS STEP BY STEP:
          1. Start with all fields from the PaperRecord
          2. Module 1 reads article_types + title + abstract → normalized type
          3. Module 2 reads journal name + ISSN → impact factor, quartile
          4. Module 3 (section parser) reads abstract → ParsedSection list
          5. Module 4 (NER) reads title + abstract → entity list + grouped dict
          6. Module 5 reads sections → DataAvailabilityInfo
          7. Everything merges into EnrichedPaperRecord
        """
        # ── Full text acquisition ──

        full = (self.fulltext.fetch(paper)
            or {})

        full_text = (
            full.get("full_text","")

        )
        # ── Module 1: Article type classification ─────────────────────────────
        article_type, confidence = self.article_classifier.classify(
            article_types_raw=paper.article_types,
            title=paper.title,
            abstract=paper.abstract,
        )

        # ── Module 2: Journal classification ─────────────────────────────────
        journal_info: JournalInfo = self.journal_classifier.classify(
            journal_name=paper.journal,
            issn=paper.issn,
        )

        # ── Module 3: Section parsing ─────────────────────────────────────────
        sections = self.section_parser.parse_abstract(paper.abstract)

        if full_text:

            full_sections = (

                self.section_parser.parse_full_text(full_text))

            sections.extend(full_sections)
        # If the paper is open access and we have full text, parse that too
        # (full text fetching will be added in a later enhancement)

        # ── Module 4: NER extraction ──────────────────────────────────────────
        entities = self.ner_extractor.extract(
            title=paper.title,
            abstract=paper.abstract,
        )
        grouped = self.ner_extractor.group_entities(entities)

        # ── Module 5: Data availability extraction ────────────────────────────
        data_availability: DataAvailabilityInfo = self.data_av_extractor.extract(sections=sections,abstract=paper.abstract,)

        study_design = (extract_design(full_text or paper.abstract))
        evidence = (extract_evidence(full_text or paper.abstract))


        # ── Merge everything into EnrichedPaperRecord ─────────────────────────
        enriched = EnrichedPaperRecord(
            **paper.model_dump(),              # All Layer 1 fields carried forward
            article_type_normalized=article_type,
            article_type_confidence=confidence,
            journal_info=journal_info,
            sections=sections,
            entities=entities,
            taxa=grouped.get("taxon", []),
            diseases=grouped.get("disease", []),
            methods=grouped.get("method", []),
            body_sites=grouped.get("body_site", []),
            treatments=grouped.get("treatment", []),
            data_availability=data_availability,
            nlp_processed_at=datetime.utcnow().isoformat(),
            nlp_version="1.0",
            full_text=full_text,
            fetch_source=full.get("fetch_source"),
            fetch_status=full.get("fetch_status"),
            study_design=study_design,
            evidence_score=evidence.get("sample_size",0),
            quality_score=
            quality_score(enriched))

        return enriched

    def load_latest(self) -> List[EnrichedPaperRecord]:
        """Loads the most recent enriched output file from disk."""
        files = sorted(PROC_DIR.glob("enriched_*.json"), reverse=True)
        if not files:
            raise FileNotFoundError("No enriched data found. Run process_all() first.")
        path = files[0]
        logger.info(f"Loading: {path}")
        with open(path) as f:
            data = json.load(f)
        return [EnrichedPaperRecord(**item) for item in data]

    def _save(self, enriched: List[EnrichedPaperRecord]) -> Path:
        """Saves enriched records to a timestamped JSON file."""
        ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        path = PROC_DIR / f"enriched_{ts}.json"
        with open(path, "w") as f:
            json.dump([r.model_dump() for r in enriched], f, indent=2,
                      ensure_ascii=False, default=str)
        return path

    def _print_summary(self, enriched: List[EnrichedPaperRecord]):
        """Prints a human-readable summary of Layer 2 results."""
        from collections import Counter

        types   = Counter(r.article_type_normalized for r in enriched)
        q_dist  = Counter(
            (r.journal_info.quartile if r.journal_info else "unknown")
            for r in enriched
        )
        da_dist = Counter(
            (r.data_availability.status if r.data_availability else "not_stated")
            for r in enriched
        )
        oa_count = sum(1 for r in enriched if r.is_open_access)

        logger.info("─" * 40)
        logger.info("NLP PIPELINE SUMMARY")
        logger.info(f"  Total enriched:         {len(enriched)}")
        logger.info(f"  Article types:          {dict(types.most_common())}")
        logger.info(f"  Journal quartiles:      {dict(q_dist.most_common())}")
        logger.info(f"  Data availability:      {dict(da_dist.most_common())}")
        logger.info(f"  Open access papers:     {oa_count}")
        logger.info("─" * 40)
